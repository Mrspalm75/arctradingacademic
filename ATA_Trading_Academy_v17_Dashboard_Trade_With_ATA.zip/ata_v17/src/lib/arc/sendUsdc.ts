export type SendUsdcRequest = {
  walletAddress: string
  recipient: string
  amount: string
  chainId: number
  tokenAddress: string
}

export type SendUsdcResult = {
  transactionId?: string
  txHash?: string
  status: "pending" | "confirmed" | "failed"
}

export interface UsdcSendProvider {
  validateRecipient(address: string): boolean
  sendUsdc(request: SendUsdcRequest): Promise<SendUsdcResult>
  getTransactionStatus(transactionId: string): Promise<SendUsdcResult>
}
