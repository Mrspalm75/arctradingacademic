export const ATA_THEME = {
  page: "min-h-screen bg-[#070B14] text-slate-100",
  shell: "mx-auto w-full max-w-[1680px] px-4 sm:px-6 lg:px-8",
  panel: "rounded-2xl border border-white/10 bg-[#0D1422]",
  panelStrong: "rounded-2xl border border-white/10 bg-[#101927]",
  metric: "rounded-xl border border-white/10 bg-[#0D1422] px-4 py-3",
  accent: "#4F8CFF",
} as const
