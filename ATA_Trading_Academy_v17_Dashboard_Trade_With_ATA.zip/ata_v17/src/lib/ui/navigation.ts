export const ATA_NAVIGATION = [
  {id:"trade",label:"Trade",href:"/trade"},
  {id:"markets",label:"Markets",href:"/markets"},
  {id:"bridge",label:"Bridge",href:"/bridge"},
  {id:"swap",label:"Swap",href:"/swap"},
  {id:"payments",label:"Payments",href:"/payments"},
  {id:"wallet",label:"Wallet",href:"/wallet"},
  {id:"lessons",label:"Lessons",href:"/lessons"},
] as const
