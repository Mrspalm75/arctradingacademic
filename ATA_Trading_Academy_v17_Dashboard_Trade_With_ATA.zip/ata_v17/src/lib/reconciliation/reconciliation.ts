export type ReconciliationState={walletBalance:string;tradingBalance:string;openOrderCount:number;openPositionCount:number;lastCheckedAt:string;status:"healthy"|"warning"|"error";discrepancies:string[]}
export interface ReconciliationService{reconcile():Promise<ReconciliationState>}
