import type {Order,Position} from "../portfolio/types"
export type CreateOrderInput={symbol:string;side:"buy"|"sell";type:"market"|"limit"|"stop"|"stop_limit";quantity:string;price?:string;stopPrice?:string;reduceOnly?:boolean;takeProfit?:string;stopLoss?:string}
export interface OrderService{createOrder(input:CreateOrderInput):Promise<Order>;cancelOrder(id:string):Promise<Order>;getOpenOrders():Promise<Order[]>;getOrderHistory():Promise<Order[]>;getPositions():Promise<Position[]>;closePosition(id:string,quantity?:string):Promise<Order>}
