export const ATA_DEFI_PRODUCTS = {
  bridge: {
    circleCctpV2: { name: "Circle CCTP v2", asset: "USDC" },
    lifi: {
      name: "LI.FI Bridge",
      bridgeTools: ["across","gasZipBridge","relaydepository","polymer","polymerStandard","lifiIntents","smartDeposits"],
    },
  },
  swap: {
    name: "LI.FI Swap",
    assets: ["USDC","EURC"],
    dexIntegrations: ["kyberswap","fly","lifiIntentsDex"],
  },
} as const
