// ATA Arc Mainnet production configuration
export const ARC_MAINNET = {
  chainId: 5042,
  chainIdHex: '0x13b2',
  chainName: 'Arc Mainnet',
  rpcUrl: 'https://rpc.mainnet.arc.io',
  wsUrl: 'wss://rpc.mainnet.arc.io',
  explorerUrl: 'https://explorer.arc.io',
  nativeCurrency: { name: 'USD Coin', symbol: 'USDC', decimals: 6 },
  usdcContract: '0x3600000000000000000000000000000000000000',
} as const

export const ATA_PRODUCTION_POLICY = {
  faucetEnabled: false,
  realUsdcFundingRequired: true,
  requireConnectedWallet: true,
  requireFreshQuote: true,
  requireWalletConfirmation: true,
  verifyTransactionBeforeSuccess: true,
} as const
