# ATA Trading Academy v12

ATA is configured for real-USDC Arc Mainnet funding with separate bridge, swap, DeFi and trading execution domains.

Production rule: no faucet. Users use real USDC. Bridge and swap transactions require connected-wallet confirmation and confirmed transaction status before ATA displays success.
