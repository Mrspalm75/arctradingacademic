# ATA Trading Academy — Independent Real-Trading Architecture

This project starts from the original ATA source and restructures it around an independent trading-terminal model.

## Product layers

1. **ATA UI** — charts, order ticket, positions, balances, education, AI and journal.
2. **ATA application API** — authenticated server endpoints for accounts, orders and positions.
3. **Execution provider** — a server-side adapter for the exchange/broker/DEX selected by ATA.
4. **Market-data provider** — a separate adapter for live quotes/order books/candles.
5. **Arc wallet layer** — wallet connection and Arc/USDC operations where applicable.

## Critical security rule

Never place exchange/broker API secrets in React/browser code. Live execution must happen server-side through an authenticated provider adapter and should require explicit user authorization.

The included execution API deliberately refuses live orders until an approved provider is implemented and `ATA_LIVE_TRADING=true` is configured.

## Next implementation step

Choose the first real execution venue (for example a specific CEX API, broker API, or an on-chain DEX/contract). Then implement that venue in `server/providers/` and add authentication, signed requests/transactions, order-status reconciliation, websocket market data, rate limits, audit logs, and kill switches.


## Current implementation status

- The frontend contains an ATA-native trading terminal and order ticket.
- The backend exposes account, positions, orders, cancellation, and health routes.
- Live order submission is blocked until a real execution adapter is installed.
- Venue secrets remain server-side.
- `server/providers/VenueAdapter.template.js` is the clean integration boundary for the first approved venue.
- `server/market-data.js` keeps candles/order books/tickers independent from execution.

### Production checklist

1. Select the first authorized venue.
2. Implement its official API/SDK in a new server-side adapter.
3. Add user authentication and account-to-venue authorization.
4. Normalize venue order/position states into ATA's internal model.
5. Add websocket market data and order-status reconciliation.
6. Add idempotency keys, rate limits, audit logs, monitoring, and a kill switch.
7. Add explicit order-review/confirmation UX before live submission.
8. Keep paper trading as a separate environment rather than mixing it with live balances.

## v3 execution safety layer

- Server-side order validation for quantity, prices, and leverage.
- Idempotency-Key required for live order submission to reduce duplicate-order risk.
- Append-only local audit log for API/order events (replace with a durable protected logging system in production).
- Provider registry keeps the first real venue as a separate adapter rather than coupling ATA to a specific exchange/broker.
- Live trading remains disabled until `ATA_LIVE_TRADING=true` and a real, authenticated provider adapter is installed.

**Important:** this project still does not execute real trades. A venue adapter and a real user authorization/account-linking system must be implemented before enabling live trading.

## v4 market-data layer

ATA now exposes a venue-neutral market-data boundary:
- `GET /api/market/ticker?symbol=BTC/USDC`
- `GET /api/market/candles?symbol=BTC/USDC&timeframe=1m&limit=500`
- `GET /api/market/orderbook?symbol=BTC/USDC&depth=20`

These endpoints intentionally return an unconfigured-provider error until an approved market-data adapter is implemented. This prevents ATA from displaying fabricated prices or implying that market data is live when it is not.

`server/events.js` defines normalized event types for future streaming market data and private order/position/account updates. A production adapter should translate the selected venue's WebSocket/stream payloads into these ATA events.

### Next production connection
1. Select the first execution venue and market-data source.
2. Implement its official API/SDK adapter on the server only.
3. Normalize symbols, balances, orders, positions, fills, and errors.
4. Add authenticated user-to-account authorization.
5. Add streaming reconciliation for ticker/order-book and private order/position updates.
6. Test in sandbox/testnet before enabling `ATA_LIVE_TRADING=true`.


## Market data
ATA can use Massive as the server-side market-data provider for real-time stocks and forex aggregates, trades and quotes. The provider key stays on the server. Massive does not provide Level-2/full order-book depth; ATA therefore exposes NBBO/top-of-book for stocks and forex. For full depth, connect a licensed depth provider such as dxFeed using its commercial integration details.


## ATA DeFi + Portal

The DeFi tab adds an independent ATA integration layer for Portal embedded wallets and supported EVM wallets. It supports: creating a Portal wallet, connecting an existing browser wallet, reading Portal balances/activity, sending assets, Li.Fi swap execution, and yield discovery when the Portal account has the yield integration enabled.

Portal's Web SDK supports `createWallet()`, balance/transaction retrieval, sending assets, and Li.Fi swaps. Portal's current public Web documentation uses Yield.xyz for yield discovery; the project therefore does not claim a direct Morpho execution path until that integration is enabled/confirmed for the ATA Portal account.

### Production security

For production, do not expose Portal client credentials unnecessarily. Portal documents Web OTP/authUrl authentication as the more secure production approach compared with putting a client API key in the DOM. Configure Portal's production environment, custom subdomain where required, RPC endpoints, and provider integrations before enabling live DeFi actions.
