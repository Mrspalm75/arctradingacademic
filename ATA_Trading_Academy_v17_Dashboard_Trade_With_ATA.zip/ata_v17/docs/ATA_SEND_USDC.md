# ATA v13 — Send USDC

ATA now has a dedicated Send USDC transaction boundary for Arc Mainnet.

## User flow

Connected wallet
→ Send
→ Enter recipient address
→ Enter USDC amount
→ Validate address
→ Show recipient + amount + network
→ Confirm in wallet
→ Submit transaction
→ Monitor transaction
→ Show confirmed/failed state
→ Refresh balance and activity

## Rules

- Users can send USDC to a user-provided compatible address.
- The transaction must be signed by the connected wallet/provider.
- ATA does not receive or store the user's private key.
- The recipient address is shown again before confirmation.
- The network and token are shown before confirmation.
- The amount is validated against the wallet's current available balance.
- Transaction status is read from the provider/on-chain result.
- ATA must not display "sent" until confirmation is received.
- Failed transactions must be shown as failed and must not be treated as successful.
- Duplicate submissions should be prevented with a request/transaction identifier.

## Arc Mainnet

Chain ID: 5042 (`0x13b2`)

USDC contract:
`0x3600000000000000000000000000000000000000`

The production UI should default to Arc Mainnet for this ATA Send flow and should not expose faucet functionality.

## UX

The Send form should contain:

- Recipient address
- Amount
- Available USDC balance
- Network: Arc Mainnet
- Token: USDC
- Estimated network fee if available
- Confirm Send button

Before signing, show a confirmation panel with the exact recipient and amount.

## Safety

"Any address" means any valid compatible address on the selected network. ATA should not claim that an arbitrary address is recoverable if the user sends to an unsupported network, contract, or incorrect address.

For production, consider an optional address-book/allowlist mode for high-value transfers while retaining direct-address sending for ordinary transfers.
