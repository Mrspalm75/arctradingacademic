# ATA v14 — Portfolio, Orders, Positions, Risk & Reconciliation

Adds production architecture for portfolio reporting, order management, positions, risk controls, reconciliation, and alerts.

Live execution remains disabled until an authenticated ExecutionProvider is configured. These modules do not fabricate fills or balances.
