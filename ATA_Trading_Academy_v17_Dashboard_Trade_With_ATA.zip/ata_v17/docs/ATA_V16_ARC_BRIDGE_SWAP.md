# ATA v16 — Arc Mainnet Bridge + Swap

Separate ATA pages:
- Bridge
- Swap
- Payments
- Wallet
- Trade
- Markets
- Lessons

Arc Mainnet:
- Chain ID: 5042
- CCTP Domain: 26
- USDC: 0x3600000000000000000000000000000000000000
- EURC: 0xbEf5f6d51CB62b58e6A8f77868681825C6fe21c1
- TokenMessengerV2: 0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d
- MessageTransmitterV2: 0x81D40F21F12A8F0E3252Bccb954D722d4c464B64
- TokenMinterV2: 0xfd78EE919681417d192449715b2594ab58f5D002
- Gateway Wallet: 0x77777777Dcc4d5A8B6E418Fd04D8997ef11000eE
- Gateway Minter: 0x2222222d7164433c4C09B0b0D809a9b52C04C205

Bridge:
1. Circle CCTP v2 — dedicated native USDC bridge.
2. LI.FI Bridge — separate aggregated cross-chain routing experience.

Swap:
- Separate Swap page.
- USDC and EURC are first-class Arc assets.
- LI.FI quote/routing architecture.
- kyberswap, fly, lifiIntentsDex integrations configured as requested.

All executable transactions require live provider responses and an explicit connected-wallet signature. ATA never stores private keys.
