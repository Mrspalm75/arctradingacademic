# ATA v17 Dashboard Copy

Primary dashboard heading: TRADE WITH ATA

Removed from the dashboard:
- # Learn to move USDC and EURC before you move real money
- Educational interface.
- Live execution, quotes and balances shown above are illustrative until a signed-in provider is connected.
- ATA does not fabricate routes, fills or balances.
- nothing here is financial advice.
